// class to class inheritance----extends
// interface to class---implements
interface MobileDimensions
{
getDimensions():string;

}



abstract class AmazonProducts
{

abstract showDetails():void;


}

class FoodProducts implements AmazonProducts
{
showDetails(): void {
    
}


}
class Products implements MobileDimensions
{
prodid:number;
prodname:string;
 //price:never=true;// only used in advanced generics
constructor(productid:number,productname:string){
this.prodid=productid;
this.prodname=productname;
}


public DisplayData():any
{
console.log(this.prodid);
console.log(this.prodname);
}



getDimensions(): string {
    return "5*6";
}

}

class ElectronicProduct extends Products{
mfgDate?:Date

public constructor(productid:number,productname:string="Mobile",manufactureDate?:Date){
super(productid,productname);
this.mfgDate=manufactureDate;


}

public override DisplayData():any{
super.DisplayData();
console.log(this.mfgDate);


}


}

let mobile=new ElectronicProduct(10,"Iphone", new Date(2021,2,20));
// mobile.prodid=10;
// mobile.prodname="Samsung";
// mobile.mfgDate=new Date(2024,1,20);
let mobileDimensions:String =mobile.getDimensions();
console.log(mobile.prodid);
console.log(mobile.prodname);
console.log(mobile.mfgDate);
console.log(mobileDimensions);
mobile.DisplayData();