//With types you can create your own type
type numericType=number;
type stringType=string;
type prodtype=string;

type Product={
productid:numericType,
productname:stringType,
productType:prodtype
}

let HardwareProduct:Product={
    productid:1,
    productname:"TV",
    productType:"NonGuarantee"
};

type Address={
streetNo:number,
streetName:string,
apartmentName:string,
societyName:string,
city:string,
state:string,
country:string,
pincode:number

}

class Supplier
{
suppid:number;
suppname:string;
suppaddress:Address;


}




















//interfaces are prominently used for inheritance
interface i1
{
n1:number;
n2:number;
}

let addNos:i1={n1:100,n2:200};