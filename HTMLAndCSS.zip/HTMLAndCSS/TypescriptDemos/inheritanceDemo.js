
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Products = /** @class */ (function () {
    function Products(productid, productname) {
        this.prodid = productid;
        this.prodname = productname;
    }
    Products.prototype.DisplayData = function () {
        console.log(this.prodid);
        console.log(this.prodname);
    };
    Products.prototype.getDimensions = function () {
        return "5*6";
    };
    return Products;
}());
var ElectronicProduct = /** @class */ (function (_super) {
    __extends(ElectronicProduct, _super);
    function ElectronicProduct(productid, productname, manufactureDate) {
        var _this = _super.call(this, productid, productname) || this;
        _this.mfgDate = manufactureDate;
        return _this;
    }
    ElectronicProduct.prototype.DisplayData = function () {
        _super.prototype.DisplayData.call(this);
        console.log(this.mfgDate);
    };
    return ElectronicProduct;
}(Products));
var mobile = new ElectronicProduct(10, "Iphone", new Date(2021, 2, 20));
// mobile.prodid=10;
// mobile.prodname="Samsung";
// mobile.mfgDate=new Date(2024,1,20);
var mobileDimensions = mobile.getDimensions();
console.log(mobile.prodid);
console.log(mobile.prodname);
console.log(mobile.mfgDate);
console.log(mobileDimensions);
mobile.DisplayData();
