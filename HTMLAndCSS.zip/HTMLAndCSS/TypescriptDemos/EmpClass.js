var Emp = /** @class */ (function () {
    function Emp(empManagerName) {
        this.deptno = 10;
        this.mgrname = "Jim";
        this.mgrname = empManagerName;
        console.log(this.mgrname);
    }
    Object.defineProperty(Emp.prototype, "Empidsetter", {
        set: function (eid) {
            this.empid = eid;
        },
        enumerable: false,
        configurable: true
    });
    Object.defineProperty(Emp.prototype, "EmpidDisp", {
        get: function () {
            return this.empid;
        },
        enumerable: false,
        configurable: true
    });
    Emp.prototype.acceptData = function (employeeid, employeename, salary, department) {
        this.empid = employeeid;
        this.empname = employeename;
        this.deptno = department;
        this.empsal = salary;
    };
    Emp.prototype.displaydata = function () {
        console.log(this.empid);
        console.log(this.empname);
        console.log(this.deptno);
        console.log(this.empsal);
    };
    return Emp;
}());
var p = new Emp("Harish");
p.Empidsetter = 11;
var empidData = p.EmpidDisp;
console.log(empidData);
// p.acceptData(123,"Jack",1000,10);
// p.displaydata();
// p.name="Jack";
// console.log(p.name);
//public/private/protected
