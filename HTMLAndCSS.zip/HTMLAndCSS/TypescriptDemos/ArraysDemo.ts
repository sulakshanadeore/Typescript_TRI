let numbers:number[]=[1,2,3,4];
let numbers1:number[]=[];
let n1=[10,211,33];

//Tuple: is a typed array and has predefined length and multiple type of data of each index

let t1:[number,string,Date];
t1=[5,"Hello",new Date(2000,9,11)];
console.log(t1[0]);
//t1=["Hello",5,new Date(2000,9,11)];

//Named Tuple
const empdata:[empid:number,empname:string,empsal:number]=[1,"Harry",10000];
console.log(empdata[0]);
console.log(empdata[1]);
console.log(empdata[2]);

let myempdata=empdata;
const[a1,a2,a3]=empdata;


const carData:{type:string,name:string,model:number}={type:"Sedan",name:"Innova",model:11};
const RideData:{type:string,name:string,model?:number}={type:"Sedan",name:"Innova"};


