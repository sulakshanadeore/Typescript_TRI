class Emp
{
    //int empid
    empid:number;
    empname:string;
    empsal:number;
    deptno:number=10;
private readonly mgrname:string="Jim";


    set Empidsetter(eid:number){
this.empid=eid;

    }

    get EmpidDisp():number
    {
return this.empid;

    }




public constructor(empManagerName:string)
{
this.mgrname=empManagerName;
console.log(this.mgrname);
}

acceptData(employeeid,employeename,salary,department):void{
this.empid=employeeid;
this.empname=employeename;
this.deptno=department;
this.empsal=salary;
}

displaydata():void
{
console.log(this.empid);
console.log(this.empname);
console.log(this.deptno);
console.log(this.empsal);

}

}

let p=new Emp("Harish");
p.Empidsetter=11;
let empidData:number=p.EmpidDisp;
console.log(empidData);

// p.acceptData(123,"Jack",1000,10);
// p.displaydata();
// p.name="Jack";
// console.log(p.name);

//public/private/protected