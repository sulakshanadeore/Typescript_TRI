var numbers = [1, 2, 3, 4];
var numbers1 = [];
var n1 = [10, 211, 33];
//Tuple: is a typed array and has predefined length and multiple type of data of each index
var t1;
t1 = [5, "Hello", new Date(2000, 9, 11)];
console.log(t1[0]);
//t1=["Hello",5,new Date(2000,9,11)];
//Named Tuple
var empdata = [1, "Harry", 10000];
console.log(empdata[0]);
console.log(empdata[1]);
console.log(empdata[2]);
